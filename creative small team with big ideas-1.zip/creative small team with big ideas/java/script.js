// cjciwgcqi


var nav = document.getElementById('nav');
var menu = document.getElementById('menu');
var about = document.getElementById('about');
var ser = document.getElementById('ser');
var folio = document.getElementById('folio');
var team = document.getElementById('team');
var testimonial = document.getElementById('testimonial');
var blog = document.getElementById('blog');
var contact = document.getElementById('contact');






window.onscroll = function() {

        if (window.pageYOffset >= menu.offsetTop) {
            nav.classList.add('sticky');



        } else {

            nav.classList.remove('sticky');

        }

        /* 
.......................................
 navigation a (ancor tag) on scroll  animate start
....................................... */


        if (window.pageYOffset >= about.offsetTop) {
            nav.classList.add('second-color');



        } else {

            nav.classList.remove('second-color');
        }

        if (window.pageYOffset >= ser.offsetTop) {
            nav.classList.add('third-color');



        } else {

            nav.classList.remove('third-color');
        }
        if (window.pageYOffset >= folio.offsetTop) {
            nav.classList.add('fourth-color');



        } else {

            nav.classList.remove('fourth-color');
        }
        if (window.pageYOffset >= team.offsetTop) {
            nav.classList.add('fifth-color');



        } else {

            nav.classList.remove('fifth-color');
        }
        if (window.pageYOffset >= testimonial.offsetTop) {
            nav.classList.add('six-color');



        } else {

            nav.classList.remove('six-color');
        }
        if (window.pageYOffset >= blog.offsetTop) {
            nav.classList.add('seven-color');



        } else {

            nav.classList.remove('seven-color');
        }

        if (window.pageYOffset >= contact.offsetTop) {
            nav.classList.add('eight-color');



        } else {

            nav.classList.remove('eight-color');
        }



        /* 
.......................................
 navigation a (ancor tag) on scroll  animate start
....................................... */


    } // this brackit imp



// .......................................
//  custom cursor animate start
// .......................................  

const cursor = document.querySelector(' .mouse');
window.addEventListener('mousemove', e => {

    cursor.setAttribute('style', 'top: ' +
        (e.pageY - 115) + 'px; left:' +
        (e.pageX - 16) + 'px;')
})


// mouse click event animate start


document.addEventListener('click', () => {

    cursor.classList.add('expand');
    setTimeout(() => {

        cursor.classList.remove('expand');
    }, 500)

})

// mouse click event animate end
/* 


// .......................................
//  custom cursor animate start
// .......................................  


.......................................
 preloader loding animate start
....................................... */

var loader = document.getElementById('preloader');

function myFunction() {

    loader.style.display = 'none';
}

/* 
.......................................
 preloader loding animate end
....................................... */

const navbtn = document.querySelector(".mobile-navbar-btn");
const header = document.querySelector(".header");

const toggleNavbar = () => {
    // alert("Plz Subscribe ");
    header.classList.toggle("active");

};

navbtn.addEventListener("click", () => toggleNavbar());